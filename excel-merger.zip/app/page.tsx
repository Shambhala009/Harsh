"use client"

import { useState } from "react"
import { useDropzone } from "react-dropzone"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Upload, FileSpreadsheet, Download, X, Check } from "lucide-react"
import { mergeExcelFiles } from "@/app/actions"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function ExcelMerger() {
  const [files, setFiles] = useState<File[]>([])
  const [isProcessing, setIsProcessing] = useState(false)
  const [progress, setProgress] = useState(0)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const [mergedFileData, setMergedFileData] = useState<{
    data: string
    filename: string
  } | null>(null)

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: {
      "application/vnd.ms-excel": [".xls"],
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [".xlsx"],
    },
    onDrop: (acceptedFiles) => {
      setFiles((prevFiles) => [...prevFiles, ...acceptedFiles])
      setError(null)
      setMergedFileData(null)
      setSuccess(false)
    },
  })

  const removeFile = (index: number) => {
    setFiles((prevFiles) => prevFiles.filter((_, i) => i !== index))
    setMergedFileData(null)
    setSuccess(false)
  }

  const handleMerge = async () => {
    if (files.length < 2) {
      setError("Please upload at least 2 Excel files to merge")
      return
    }

    try {
      setIsProcessing(true)
      setProgress(10)
      setError(null)

      // Create FormData to send files
      const formData = new FormData()
      files.forEach((file, index) => {
        formData.append(`file-${index}`, file)
      })

      // Simulate progress
      const progressInterval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 90) {
            clearInterval(progressInterval)
            return 90
          }
          return prev + 10
        })
      }, 300)

      const result = await mergeExcelFiles(formData)

      clearInterval(progressInterval)
      setProgress(100)

      if (result.error) {
        setError(result.error)
      } else if (result.success && result.data) {
        setMergedFileData({
          data: result.data,
          filename: result.filename,
        })
        setSuccess(true)
      }
    } catch (err) {
      setError("An error occurred while merging files. Please try again.")
      console.error(err)
    } finally {
      setIsProcessing(false)
    }
  }

  const handleDownload = () => {
    if (!mergedFileData) return

    // Convert base64 to blob
    const byteCharacters = atob(mergedFileData.data)
    const byteArrays = []

    for (let offset = 0; offset < byteCharacters.length; offset += 512) {
      const slice = byteCharacters.slice(offset, offset + 512)

      const byteNumbers = new Array(slice.length)
      for (let i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i)
      }

      const byteArray = new Uint8Array(byteNumbers)
      byteArrays.push(byteArray)
    }

    const blob = new Blob(byteArrays, { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" })

    // Create download link
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = mergedFileData.filename
    document.body.appendChild(a)
    a.click()

    // Cleanup
    window.URL.revokeObjectURL(url)
    document.body.removeChild(a)
  }

  return (
    <div className="container mx-auto py-10 px-4">
      <h1 className="text-3xl font-bold text-center mb-8">Excel File Merger</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Upload Excel Files</CardTitle>
            <CardDescription>Select or drag and drop multiple Excel files (.xlsx, .xls)</CardDescription>
          </CardHeader>
          <CardContent>
            <div
              {...getRootProps()}
              className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
                isDragActive ? "border-primary bg-primary/5" : "border-gray-300 hover:border-primary"
              }`}
            >
              <input {...getInputProps()} />
              <Upload className="mx-auto h-12 w-12 text-gray-400" />
              <p className="mt-2 text-sm text-gray-600">
                {isDragActive
                  ? "Drop the Excel files here..."
                  : "Drag and drop Excel files here, or click to select files"}
              </p>
            </div>

            {files.length > 0 && (
              <div className="mt-6">
                <h3 className="font-medium mb-2">Selected Files ({files.length})</h3>
                <ul className="space-y-2">
                  {files.map((file, index) => (
                    <li key={index} className="flex items-center justify-between bg-gray-50 p-2 rounded">
                      <div className="flex items-center">
                        <FileSpreadsheet className="h-5 w-5 text-green-600 mr-2" />
                        <span className="text-sm truncate max-w-[200px]">{file.name}</span>
                      </div>
                      <Button variant="ghost" size="icon" onClick={() => removeFile(index)} disabled={isProcessing}>
                        <X className="h-4 w-4" />
                      </Button>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
          <CardFooter>
            <Button onClick={handleMerge} disabled={files.length < 2 || isProcessing} className="w-full">
              {isProcessing ? "Processing..." : "Merge Excel Files"}
            </Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Merge Status</CardTitle>
            <CardDescription>View the status of your Excel file merge</CardDescription>
          </CardHeader>
          <CardContent>
            {isProcessing && (
              <div className="space-y-4">
                <p className="text-sm">Merging your Excel files...</p>
                <Progress value={progress} className="h-2" />
                <p className="text-xs text-gray-500 text-right">{progress}%</p>
              </div>
            )}

            {error && (
              <Alert variant="destructive" className="mb-4">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {success && (
              <div className="flex items-center space-x-2 mb-4 bg-green-50 p-3 rounded-md">
                <Check className="h-5 w-5 text-green-600" />
                <p className="text-sm text-green-700">Files successfully merged!</p>
              </div>
            )}

            {!isProcessing && !error && !success && files.length > 0 && (
              <div className="text-center py-8">
                <Badge variant="outline" className="mb-2">
                  Ready to merge
                </Badge>
                <p className="text-sm text-gray-500">Click the "Merge Excel Files" button to start processing</p>
              </div>
            )}

            {!isProcessing && !error && !success && files.length === 0 && (
              <div className="text-center py-12">
                <p className="text-sm text-gray-500">Upload at least two Excel files to begin</p>
              </div>
            )}

            {mergedFileData && (
              <div className="mt-6">
                <Button variant="outline" className="w-full flex items-center justify-center" onClick={handleDownload}>
                  <Download className="mr-2 h-4 w-4" />
                  Download Merged File
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

