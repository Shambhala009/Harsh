"use server"

import * as XLSX from "xlsx"

export async function mergeExcelFiles(formData: FormData) {
  try {
    // Get all files from formData
    const files: File[] = []
    for (const [key, value] of formData.entries()) {
      if (value instanceof File) {
        files.push(value)
      }
    }

    if (files.length < 2) {
      return { error: "Please upload at least 2 Excel files to merge" }
    }

    // Process each file and collect worksheets
    const workbooks = []
    for (const file of files) {
      const buffer = await file.arrayBuffer()
      try {
        const workbook = XLSX.read(buffer, { type: "array" })
        workbooks.push({ name: file.name, workbook })
      } catch (err) {
        return { error: `Failed to read file: ${file.name}. Make sure it's a valid Excel file.` }
      }
    }

    // Create a new workbook for the merged result
    const mergedWorkbook = XLSX.utils.book_new()

    // Process each workbook
    for (const { name, workbook } of workbooks) {
      // Get all sheet names
      const sheetNames = workbook.SheetNames

      // Process each sheet
      for (const sheetName of sheetNames) {
        const worksheet = workbook.Sheets[sheetName]

        // Create a unique sheet name to avoid conflicts
        const fileBaseName = name.split(".").slice(0, -1).join(".")
        const uniqueSheetName = `${fileBaseName} - ${sheetName}`.substring(0, 31) // Excel has a 31 char limit for sheet names

        // Add the worksheet to the merged workbook
        XLSX.utils.book_append_sheet(mergedWorkbook, worksheet, uniqueSheetName)
      }
    }

    // Generate the merged Excel file as a base64 string
    const excelOutput = XLSX.write(mergedWorkbook, {
      bookType: "xlsx",
      type: "base64",
    })

    // Generate a filename
    const timestamp = new Date().toISOString().replace(/[:.]/g, "-")
    const uniqueId = Math.random().toString(36).substring(2, 10)
    const filename = `merged-excel-${timestamp}-${uniqueId}.xlsx`

    // Return the base64 data and filename
    return {
      success: true,
      data: excelOutput,
      filename: filename,
    }
  } catch (error) {
    console.error("Error merging Excel files:", error)
    return { error: "Failed to merge Excel files. Please try again." }
  }
}

